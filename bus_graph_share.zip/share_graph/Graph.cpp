#include "Graph.hpp"

#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <fstream>
#include <functional>
#include <limits>
#include <queue>
#include <set>
#include <sstream>
#include <stdexcept>
#include <unordered_set>

// ───────────────────────── 생성 ─────────────────────────
int Graph::addNode(int stopId) {
    auto it = idToIdx.find(stopId);
    if (it != idToIdx.end()) return it->second;
    int idx = static_cast<int>(nodes.size());
    Node n;
    n.id = stopId;
    nodes.push_back(std::move(n));
    idToIdx[stopId] = idx;
    return idx;
}

int Graph::addEdge(Edge e) {
    e.u = addNode(e.srcId);
    e.v = addNode(e.dstId);
    int idx = static_cast<int>(edges.size());
    nodes[e.u].out.push_back(idx);
    nodes[e.v].in.push_back(idx);
    edges.push_back(std::move(e));
    return idx;
}

// ───────────────────────── 랜덤 액세스 ─────────────────────────
int Graph::indexOf(int stopId) const {
    auto it = idToIdx.find(stopId);
    return it == idToIdx.end() ? -1 : it->second;
}

Node& Graph::operator[](int stopId) {
    int i = indexOf(stopId);
    if (i < 0) throw std::out_of_range("unknown stop id: " + std::to_string(stopId));
    return nodes[i];
}

const Node& Graph::operator[](int stopId) const {
    int i = indexOf(stopId);
    if (i < 0) throw std::out_of_range("unknown stop id: " + std::to_string(stopId));
    return nodes[i];
}

// ───────────────────────── 인접 정보 ─────────────────────────
std::vector<int> Graph::neighbors(int stopId) const {
    std::vector<int> res;
    std::unordered_set<int> seen;
    for (int ei : (*this)[stopId].out) {
        int d = edges[ei].dstId;
        if (seen.insert(d).second) res.push_back(d);
    }
    return res;
}

std::vector<int> Graph::edgesBetween(int srcId, int dstId) const {
    std::vector<int> res;
    for (int ei : (*this)[srcId].out)
        if (edges[ei].dstId == dstId) res.push_back(ei);
    return res;
}

std::vector<std::string> Graph::routesAt(int stopId) const {
    std::set<std::string> s;   // 정렬 + 중복 제거
    const Node& n = (*this)[stopId];
    for (int ei : n.out) s.insert(edges[ei].routeName);
    for (int ei : n.in) s.insert(edges[ei].routeName);
    return {s.begin(), s.end()};
}

void Graph::writeAdjList(const std::string& path) const {
    std::ofstream f(path);
    for (const Node& n : nodes) {
        f << n.id;
        for (int d : neighbors(n.id)) f << ' ' << d;
        f << '\n';
    }
}

// ───────────────────────── 탐색 ─────────────────────────
std::vector<int> Graph::reachable(int srcId) const {
    std::vector<char> seen(nodes.size(), 0);
    std::vector<int> res;
    std::queue<int> q;
    int s = indexOf(srcId);
    if (s < 0) return res;
    seen[s] = 1;
    q.push(s);
    while (!q.empty()) {
        int u = q.front(); q.pop();
        res.push_back(nodes[u].id);
        for (int ei : nodes[u].out) {
            int v = edges[ei].v;
            if (!seen[v]) { seen[v] = 1; q.push(v); }
        }
    }
    return res;
}

PathResult Graph::shortestPath(int srcId, int dstId, double alpha, double defaultCongestion) const {
    PathResult r;
    int s = indexOf(srcId), t = indexOf(dstId);
    if (s < 0 || t < 0) return r;

    const double INF = std::numeric_limits<double>::infinity();
    std::vector<double> dist(nodes.size(), INF);
    std::vector<int> prevEdge(nodes.size(), -1);
    using Item = std::pair<double, int>;                       // (거리, 노드 인덱스)
    std::priority_queue<Item, std::vector<Item>, std::greater<Item>> pq;  // 최소 힙

    dist[s] = 0;
    pq.push({0.0, s});
    while (!pq.empty()) {
        auto [d, u] = pq.top(); pq.pop();
        if (u == t) break;
        if (d > dist[u]) continue;
        for (int ei : nodes[u].out) {
            const Edge& e = edges[ei];
            double nd = d + e.cost(alpha, defaultCongestion);
            if (nd < dist[e.v]) {
                dist[e.v] = nd;
                prevEdge[e.v] = ei;
                pq.push({nd, e.v});
            }
        }
    }
    if (dist[t] == INF) return r;

    r.cost = dist[t];
    for (int cur = t; cur != s; cur = edges[prevEdge[cur]].u) r.edges.push_back(prevEdge[cur]);
    std::reverse(r.edges.begin(), r.edges.end());
    for (int ei : r.edges) r.totalTime += edges[ei].travelTime;
    return r;
}

// ───────────────────────── 저장 / 불러오기 ─────────────────────────
// 포맷: "BUSG" | version | hour | capLoad | 노드수 | 노드ID들 | 간선수 | 간선들  (리틀엔디언)
namespace {
const char MAGIC[4] = {'B', 'U', 'S', 'G'};
const int32_t VERSION = 2;

template <class T> void wr(std::ofstream& f, const T& x) { f.write(reinterpret_cast<const char*>(&x), sizeof(T)); }
void wrs(std::ofstream& f, const std::string& s) {
    wr<uint32_t>(f, static_cast<uint32_t>(s.size()));
    f.write(s.data(), static_cast<std::streamsize>(s.size()));
}
template <class T> T rd(std::ifstream& f) { T x{}; f.read(reinterpret_cast<char*>(&x), sizeof(T)); return x; }
std::string rds(std::ifstream& f) {
    uint32_t n = rd<uint32_t>(f);
    std::string s(n, '\0');
    f.read(&s[0], n);
    return s;
}
}  // namespace

void Graph::save(const std::string& path) const {
    std::ofstream f(path, std::ios::binary);
    if (!f) throw std::runtime_error("cannot write: " + path);
    f.write(MAGIC, 4);
    wr(f, VERSION);
    wr<int32_t>(f, hour);
    wr(f, capLoad);
    wr<int32_t>(f, numNodes());
    for (const Node& n : nodes) wr<int32_t>(f, n.id);
    wr<int32_t>(f, numEdges());
    for (const Edge& e : edges) {
        wr<int32_t>(f, e.srcId); wr<int32_t>(f, e.dstId);
        wr<int32_t>(f, e.routeId); wrs(f, e.routeName); wr<int32_t>(f, e.seq);
        wr(f, e.travelTime); wr(f, e.load); wr(f, e.congestion);
    }
}

Graph Graph::load(const std::string& path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) throw std::runtime_error("cannot open: " + path);
    char m[4];
    f.read(m, 4);
    if (std::string(m, 4) != "BUSG") throw std::runtime_error("not a graph file: " + path);
    if (rd<int32_t>(f) != VERSION) throw std::runtime_error("version mismatch: " + path);

    Graph g;
    g.hour = rd<int32_t>(f);
    g.capLoad = rd<double>(f);
    int nn = rd<int32_t>(f);
    g.nodes.reserve(nn);
    g.idToIdx.reserve(nn * 2);
    for (int i = 0; i < nn; ++i) {
        g.addNode(rd<int32_t>(f));
    }
    int ne = rd<int32_t>(f);
    g.edges.reserve(ne);
    for (int i = 0; i < ne; ++i) {
        Edge e;
        e.srcId = rd<int32_t>(f); e.dstId = rd<int32_t>(f);
        e.routeId = rd<int32_t>(f); e.routeName = rds(f); e.seq = rd<int32_t>(f);
        e.travelTime = rd<double>(f); e.load = rd<double>(f); e.congestion = rd<double>(f);
        g.addEdge(std::move(e));
    }
    if (!f) throw std::runtime_error("corrupted file: " + path);
    return g;
}

std::string Graph::summary() const {
    double sum = 0;
    int cnt = 0;
    for (const Edge& e : edges) if (e.hasData()) { sum += e.congestion; ++cnt; }
    char buf[160];
    std::snprintf(buf, sizeof buf, "Graph(hour=%02d, nodes=%d, edges=%d, avg_congestion=%.3f)",
                  hour, numNodes(), numEdges(), cnt ? sum / cnt : 0.0);
    return buf;
}

Graph loadGraph(int hour, const std::string& folder) {
    char name[32];
    std::snprintf(name, sizeof name, "/graph_%02d.bin", hour);
    return Graph::load(folder + name);
}
